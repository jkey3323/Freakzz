<?php
/*
____            _             ____       _            _           ___   ___  
/ ___|  ___  ___| |_ ___  _ __|  _ \ _ __(_)_   ____ _| |_ ___    ( _ ) ( _ ) 
\___ \ / _ \/ __| __/ _ \| '__| |_) | '__| \ \ / / _` | __/ _ \   / _ \ / _ \ 
 ___) |  __/ (__| || (_) | |  |  __/| |  | |\ V / (_| | ||  __/  | (_) | (_) |
|____/ \___|\___|\__\___/|_|  |_|   |_|  |_| \_/ \__,_|\__\___|___\___/ \___/ 
                                                             |_____|          

Join our community
Facebook Groups : https://www.facebook.com/groups/621105481775437/
Telegram Chanel : https://t.me/sectorprivate88
Need our help : sectorprivate88 [at] gmail.com

if link die you can find at (https://pastebin.com/2bwFRSjP) for updated link

*/
session_start();
session_destroy();
echo "<script type='text/javascript'>window.top.location='login.php';</script>";